﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using Emgu.CV;
using Emgu.CV.Cuda;
using Emgu.CV.CvEnum;
using Emgu.CV.Flann;
using Emgu.CV.Structure;
using Emgu.CV.Util;
//Tommy Shinozaki
//12-1-2018
//Pick'n'Place Code
//Side note: the file name is "lab5_contours" because I built this code off the code I wrote for Lab 5.
//Its a minor detail... figured I'd mention it.
namespace lab5_contours
{
    public partial class Form1 : Form
    {
        private VideoCapture _capture;
        private Thread _captureThread;

        //Intial value for how many shapes on screen
        private int count = 0;
        //Intial value for the image brightness
        private int Upper = 255;
        //Intital value for the image threshold
        private int Lower = 156;

        public Form1()
        {
            InitializeComponent();
        }
         private void Form1_Load(object sender, EventArgs e)
        {
            _capture = new VideoCapture(1);
            _captureThread = new Thread(DisplayWebcam);
            _captureThread.Start();

            trackBar1.Maximum = 255;
            trackBar1.TickFrequency = 5;
            trackBar1.LargeChange = 3;
            trackBar1.SmallChange = 1;

            trackBar2.Maximum = 255;
            trackBar2.TickFrequency = 5;
            trackBar2.LargeChange = 3;
            trackBar2.SmallChange = 1;
        }

        private void DisplayWebcam()
        {
            while (_capture.IsOpened)
            {
                count = 0;
                //Pictures and thresholds
                Mat frame = _capture.QueryFrame();
                CvInvoke.Resize(frame, frame, pictureBox1.Size);
                
                Image<Bgr, Byte> img = frame.ToImage<Bgr, Byte>();

                // Erode and dilate to clear noise
                var findEdges = img.SmoothGaussian(5).Convert<Gray, byte>().ThresholdBinary(new Gray(Lower), new Gray(Upper)).Erode(5).Dilate(5);

                VectorOfVectorOfPoint contours = new VectorOfVectorOfPoint();
                Mat draw = new Mat();
                CvInvoke.FindContours(findEdges, contours, draw, Emgu.CV.CvEnum.RetrType.Ccomp, ChainApproxMethod.ChainApproxSimple);

                //For each shape, finds its center, labels the shape type and coordinate of its center
                for (int i = 0; i < contours.Size; i++)
                {
                    double parameter = CvInvoke.ArcLength(contours[i], true);
                    VectorOfPoint positions = new VectorOfPoint();
                    CvInvoke.ApproxPolyDP(contours[i], positions, 0.03 * parameter, true);

                    CvInvoke.DrawContours(img, contours, i, new MCvScalar(255, 255, 0), 3);

                    // Find the center
                    var moments = CvInvoke.Moments((contours[i]));
                    int x = (int)(moments.M10 / moments.M00);
                    int y = (int)(moments.M01 / moments.M00);

                    if (positions.Size == 3)
                    {
                        //If it has three sides, display that its a triangle and its centroid's coordinates
                        CvInvoke.PutText(img, "+ Tri" + x.ToString() + "," + y.ToString(),
                            new Point(x, y),
                            FontFace.HersheySimplex, 0.5, new MCvScalar(0, 255, 0), 1);
                        count += 1;
                    }

                    if (positions.Size == 4)
                    {
                        //If it has four sides, display that its a square and its centroid's coordinates
                        CvInvoke.PutText(img, "+ Squ" + x.ToString() + "," + y.ToString(),
                            new Point(x, y),
                            FontFace.HersheySimplex, 0.5, new MCvScalar(0, 0, 255), 1);
                        count += 1;
                    }
                }

                //Label how many shapes are in the image
                Invoke(new Action(() => { label1.Text = $"Number of shapes: {count - 1}"; }));

                //Displays all 3 Images: the original,
                //a black-and-white one depicting the threshold effects,
                //and one with outlines around the shapes
                pictureBox1.Image = frame.Bitmap;
                pictureBox2.Image = findEdges.Bitmap;
                pictureBox3.Image = img.Bitmap;
            }
        }
       
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Shutdowns the program
            _captureThread.Abort();
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            //Display trackbar value in the textbox
            textBox1.Text = "" + trackBar1.Value;
            Upper = trackBar1.Value;
        }
       

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            //Display trackbar value in the textbox
            textBox2.Text = "" + trackBar2.Value;
            Lower = trackBar2.Value;
        }

        private void runARMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Currently does nothing.
            //This would have been what's starts the program.
            //Theoretically, after you click "Run ARM", the coordinates of each shape
            //gets sent to the arduino for the arm to pick-and-place shapes.
        }
    }
}
